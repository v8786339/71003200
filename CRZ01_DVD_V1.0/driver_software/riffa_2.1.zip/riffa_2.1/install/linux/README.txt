Linux kernel versions 2.6.27+ are supported. To install, find the 

source/driver/linux 

directory and compile and install from there. After installation, you'll be able
to install the bindings for other languages. See the language subdirectories.

For further details, see the RIFFA 2.0 website at:
http://cseweb.ucsd.edu/~mdjacobs 

