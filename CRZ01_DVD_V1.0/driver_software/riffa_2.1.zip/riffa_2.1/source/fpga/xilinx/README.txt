This directory contains designs and prebuilt .bit files for common Xilinx 
development boards. Instructions for using the designs are contained in each
directory. If you have a development board for which there is no design, you
will need to follow the instructions for a similar FPGA family and adapt the
design for your board. 

Adapting the design is not that difficult. The RIFFA 2.0 HDL is the same for all 
designs. The only differences are in generating the Xilinx PCIe Endpoint core, 
generated the .ucf file and top level module. The RIFFA 2.0 board reference
designs come with a top level file. Xilinx tools provide with the PCIe Endpoint 
core, the .ucf, and a top level file for their "example application". To adapt  
the RIFFA 2.0 reference design to your board, you only need to generate a PCIe 
Endpoint for your board, and adapt the top level module that Xilinx provides as 
part of their "example application". You will likely want to compare the RIFFA 
2.0 provided top level design to the Xilinx generate one during this process.

Xilinx has two different methods for creating PCIe Endpoint cores depending on
whether you are using ISE or Vivado. You will find instructions for creating
RIFFA 2.0 designs using either method in the subdirectories.
