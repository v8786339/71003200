/*******************************************************************************
 * This software is Copyright © 2012 The Regents of the University of
 * California. All Rights Reserved.
 *
 * Permission to copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without fee,
 * and without a written agreement is hereby granted, provided that the above
 * copyright notice, this paragraph and the following three paragraphs appear in
 * all copies.
 *
 * Permission to make commercial use of this software may be obtained by
 * contacting:
 * Technology Transfer Office
 * 9500 Gilman Drive, Mail Code 0910
 * University of California
 * La Jolla, CA 92093-0910
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of the
 * University of California. The software program and documentation are supplied
 * "as is", without any accompanying services from The Regents. The Regents does
 * not warrant that the operation of the program will be uninterrupted or error-
 * free. The end-user understands that the program was developed for research
 * purposes and is advised not to rely exclusively on the program for any
 * reason.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO
 * ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR
 * CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING
 * OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE. THE UNIVERSITY OF
 * CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 * THE SOFTWARE PROVIDED HEREUNDER IS ON AN "AS IS" BASIS,
 * AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATIONS TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 */

/*
 * Filename: jriffa.c
 * Version: 2.0
 * Description: Java JNI library for calling RIFFA.
 * Author: Matthew Jacobsen
 * History: @mattj: Initial release. Version 2.0.
 */

#include <limits.h>
#include <riffa.h>
#include "jriffa.h"
#include <stdio.h>

JNIEXPORT jint JNICALL Java_edu_ucsd_cs_riffa_Fpga_jFpgaList(JNIEnv *env, jobject obj, jobject info) {
	int r;
	int i;
	fpga_info_list list;
	jclass cls;
	jstring name;
	jmethodID setNumFpgas;
	jmethodID setName;
	jmethodID setId;
	jmethodID setNumChannels;
	jmethodID setVendorId;
	jmethodID setDeviceId;
	if ((r = fpga_list(&list)) == 0) {
		cls = (*env)->FindClass(env, "edu/ucsd/cs/riffa/FpgaInfo");
		setNumFpgas = (*env)->GetMethodID(env, cls, "setNumFpgas", "(I)V");
		(*env)->CallVoidMethod(env, info, setNumFpgas, list.num_fpgas);
		for (i = 0; i < list.num_fpgas; i++) {
			setName = (*env)->GetMethodID(env, cls, "setName", "(ILjava/lang/String;)V");
			name = (*env)->NewStringUTF(env, list.name[i]);
			(*env)->CallVoidMethod(env, info, setName, i, name);
			setNumChannels = (*env)->GetMethodID(env, cls, "setNumChannels", "(II)V");
			(*env)->CallVoidMethod(env, info, setNumChannels, i, list.num_chnls[i]);
			setId = (*env)->GetMethodID(env, cls, "setId", "(II)V");
			(*env)->CallVoidMethod(env, info, setId, i, list.id[i]);
			setVendorId = (*env)->GetMethodID(env, cls, "setVendorId", "(II)V");
			(*env)->CallVoidMethod(env, info, setVendorId, i, list.vendor_id[i]);
			setDeviceId = (*env)->GetMethodID(env, cls, "setDeviceId", "(II)V");
			(*env)->CallVoidMethod(env, info, setDeviceId, i, list.device_id[i]);
		}
	}
	return r;
}

JNIEXPORT jlong JNICALL Java_edu_ucsd_cs_riffa_Fpga_jFpgaOpen(JNIEnv *env, jobject obj, jint id) {
	fpga_t * fpga = fpga_open((int)id);
	return (jlong)fpga;
}

JNIEXPORT void JNICALL Java_edu_ucsd_cs_riffa_Fpga_jFpgaClose(JNIEnv *env, jobject obj, jlong fpga) {
	fpga_close((fpga_t *)fpga);
}

JNIEXPORT jint JNICALL Java_edu_ucsd_cs_riffa_Fpga_jFpgaSend(JNIEnv *env, jobject obj, jlong fpga,
	jint chnl, jobject buffer, jint len, jint destoff, jint last, jlong timeout) {
	jlong datalen;
	unsigned int ulen;
	unsigned int lgt;
	void * data;
	data = (*env)->GetDirectBufferAddress(env, buffer);
	datalen = (*env)->GetDirectBufferCapacity(env, buffer);
	if (data == NULL || datalen == -1)
		return -1; // Means cannot get access to ByteBuffer underlying pointer
	ulen = (unsigned int)len;
	lgt = (ulen > (datalen>>2) ? (datalen>>2) : ulen);
	return fpga_send((fpga_t *)fpga, chnl, data, lgt, destoff, last, timeout);
}

JNIEXPORT jint JNICALL Java_edu_ucsd_cs_riffa_Fpga_jFpgaRecv(JNIEnv *env, jobject obj, jlong fpga,
	jint chnl, jobject buffer, jlong timeout) {
	jlong datalen;
	unsigned int lgt;
	void * data;
	data = (*env)->GetDirectBufferAddress(env, buffer);
	datalen = (*env)->GetDirectBufferCapacity(env, buffer);
	if (data == NULL || datalen == -1)
		return -1; // Means cannot get access to ByteBuffer underlying pointer
	lgt = (datalen>>2);
	return fpga_recv((fpga_t *)fpga, chnl, data, lgt, timeout);
}

JNIEXPORT void JNICALL Java_edu_ucsd_cs_riffa_Fpga_jFpgaReset(JNIEnv *env, jobject obj, jlong fpga) {
	fpga_reset((fpga_t *)fpga);
}

