Currently only Windows 7 (32/64) is supported. In the subdirectory use the 
provided setup.exe program to install the RIFFA driver and native C/C++ library.
After installation, you'll be able to install the bindings for other languages. 
See the installation directory in Program Files.

The setup_dbg.exe installer installs a driver with additional debugging output.
You can install the setup_dbg.exe version and then later use setup.exe to 
install the non-debug output version.

For further details, see the RIFFA website at: riffa.ucsd.edu


