The Linux C/C++ library is compiled and installed with the kernel driver. This
directory contains a sample application subdirectory that you can use to test
your design. 
