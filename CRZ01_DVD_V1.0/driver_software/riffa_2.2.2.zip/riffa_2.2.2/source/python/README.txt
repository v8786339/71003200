To install the Python bindings for RIFFA:

1) Decompress the riffa-2.0 archive in the dist subdirectory
2) Run: python setup.py install

If you have any questions feel free to check out the 
RIFFA website at http://cseweb.ucsd.edu/~mdjacobs


