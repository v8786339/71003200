- VADJ 2.5V
- MII mode, connected to PS7's Ethernet 0(PHY 0) and Ethernet 1(PHY 1)

