- VADJ 2.5V. It was successfully tested with 1.8V and 3.3V.
- RGMII mode, using a GMII-to-RGMII converter. Connected to PS7's Ethernet 0(PHY 0) and Ethernet 1(PHY 1)

