# AD-DAC-FMC-EBZ reference HDL design for A10SoC

|||
| ------ | ------ |
| Wiki  | https://wiki.analog.com/resources/eval/user-guides/ad-dac-fmc-ebz |
| FMC Location | FMCA HPC Slot |
| Configuration file | ../common/config.tcl |
