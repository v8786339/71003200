 **AD9434-FMC-500EBZ** For more info see: [https://wiki.analog.com/start?do=search&id=ad9434-fmc] (https://wiki.analog.com/start?do=search&id=ad9434-fmc)

Building Bare Metal software:
- Go to one of the supported carrier boards (e.g. zc706) and use make [https://en.wikipedia.org/wiki/Makefile] (https://en.wikipedia.org/wiki/Makefile)
- Or open ./ad9434_fmc_500ebz.mk and build the project manually (see platform_drivers.h and include your platform)