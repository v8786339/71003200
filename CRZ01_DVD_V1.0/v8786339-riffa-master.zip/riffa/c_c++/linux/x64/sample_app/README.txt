The testutil example application works with the Verilog chnl_tester module
which receives data and then sends data back to the workstation. 

To compile the example application:

make

The riffa C/C++ library must be installed (it gets installed with the driver).
