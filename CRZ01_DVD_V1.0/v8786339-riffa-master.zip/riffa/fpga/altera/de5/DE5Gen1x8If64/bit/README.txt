Non-Qsys DE5 Designs are no longer generated as of the RIFFA 2.2.2
release. Please follow the RIFFA documentation to generate the DE5 example
designs.
